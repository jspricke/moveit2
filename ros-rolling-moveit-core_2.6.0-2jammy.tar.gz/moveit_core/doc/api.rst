.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   moveit.core
